<?php
function questionnaire_answer(){
//  echo "I AM HERE";
  global $current_user, $wpdb;
  $mysqldate = date("Y-m-d H:i:s");
  if(isset($_POST['answer_submit'])){
    $POST      = array_map( 'stripslashes_deep', $_POST);
	unset($POST['answer_submit']);
    $data = $POST;
	//echo '<pre>'.print_r($data, 1).'</pre>';
	//echo get_client_ip();
	foreach($data as $key => $value){
	   $object_id = $wpdb->insert($wpdb->prefix .'answers', array(
	    'id' => NULL,
		'qid' => $key,
		'answered_by' => 0,
		'answer' => intval($value),
		'ip' => get_client_ip(),
		'cdate' => $mysqldate
	  )); 
	  //echo $key.' => '.$value;
   }
   echo '<div class="msg">Thank you for submitting your oppinion</div>';
  }
  $rows = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."questionnaire", ARRAY_A);
  ?>
<table class="widefat">
<form id="answer-form" name="answer-form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
<?php
if(!empty($rows)){
foreach($rows as $row){ 
?>
  <tr><td><?php echo $row['question']; ?></td></tr>
  <tr><td><input type="text" name="<?php echo $row['id']; ?>" required  /></td></tr>

 <?php } 
 }
?>
 <tr><td> <input name="answer_submit" type="submit" class="button-secondary" value= "Submit"/></td></tr>
</form>
</table>
<?php
}
function get_client_ip() {
$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if(getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if(getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if(getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if(getenv('HTTP_FORWARDED'))
   $ipaddress = getenv('HTTP_FORWARDED');
else if(getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';
return $ipaddress;
} 
function auto_add_http($url) {
    if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
        $url = "http://" . $url;
    }
    return $url;
}//function close
    function after ($this, $inthat)
    {
        if (!is_bool(strpos($inthat, $this)))
        return substr($inthat, strpos($inthat,$this)+strlen($this));
    };

    function after_last ($this, $inthat)
    {
        if (!is_bool(strrevpos($inthat, $this)))
        return substr($inthat, strrevpos($inthat, $this)+strlen($this));
    };

    function before ($this, $inthat)
    {
        return substr($inthat, 0, strpos($inthat, $this));
    };
	function before_last ($this, $inthat)
    {
        return substr($inthat, 0, strrevpos($inthat, $this));
    };

    function between ($this, $that, $inthat)
    {
        return before ($that, after($this, $inthat));
    };
function strrevpos($instr, $needle)
{
    $rev_pos = strpos (strrev($instr), strrev($needle));
    if ($rev_pos===false) return false;
    else return strlen($instr) - $rev_pos - strlen($needle);
};