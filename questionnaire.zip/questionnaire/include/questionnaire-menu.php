<?php
function questionnaire_plugin_admin_menu() {
    add_menu_page(
        'Questionnaire',
        'Questionnaire',
        'manage_options',
        'questionnaire',
        'questionnaire_function', // Callback, leave empty
        'dashicons-calendar',
        5 // Position
    );
}

add_action( 'admin_menu', 'questionnaire_plugin_admin_menu' );

function questionnaire_function(){
global $current_user, $wpdb;
if(isset($_POST['add_question'])){
$mysqldate = date("Y-m-d H:i:s");
$user_id = intval( $_POST['submit_by'] );
$question = sanitize_text_field( $_POST['question'] );
  if($_POST['add_question'] == "Save"){
   $object_id = $wpdb->insert($wpdb->prefix .'questionnaire', array(
    'submit_by' => $user_id,
	'question' => $question,
	'created' => $mysqldate,
	'updated' => $mysqldate
   ));
  }elseif($_POST['add_question'] == "Update"){
   $object_id = $wpdb->update($wpdb->prefix .'questionnaire', 
	array( 'settings' => $campaign_str	), 
	array( 'id' => $id )
    );
  }
}
$rows = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."questionnaire", ARRAY_A);
?>
<div class="view-left-area">
<div class="question-area">
<h4>Questionnaire</h4>
<table class="widefat">
<tbody>
  <tr><th>Created by</th><th>Questionnaire</th><th>Date</th></tr>
</tbody>
<?php 
if(!empty($rows)){
foreach($rows as $row){ 
?>
  <tr><td><?php echo $row['submit_by']; ?>
  </td><td><?php echo $row['question']; ?></td><td><?php echo $row['created']; ?></td></tr>
 <?php } 
 }?>
</table>
</div>
<div class="submited-area">
<form id="question-form" name="question-form" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
 <table border="0" cellspacing="0" cellpadding="0" class="widefat">
 <h4>Submit Your Question</h4>
   <tr><td>Question:</td><td><input name="question" type="text" value="" /></td></tr>
	 <tr><td colspan="3"> &nbsp;&nbsp;&nbsp;&nbsp;<input name="add_question" type="submit" class="button-secondary" value= "Save"/></td></tr>
	</table>
<input name="submit_by" type="hidden" value= "<? echo $current_user->ID; ?>"/>
</form>
</div>
</div>
<div class="view-right-area">
<h4>Survey Result</h4>
<div class="chart-area">
<?php 

$rows = $wpdb->get_results("SELECT qid , COUNT(qid) as val FROM ".$wpdb->prefix."answers GROUP BY qid", ARRAY_A);

?>
<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Question');
        data.addColumn('number', 'Answer');
        data.addRows([
		<?php
		//$rows = array('pie' => 234, 'pie1' => 194, 'pie2' => 567);

		foreach($rows as $row){
            echo "['Ques ".$row['qid']."', ".$row['val']."],";
          }
		  ?>
        ]);

        // Set chart options
        var options = {'title':'Questionnaire Answer Chart'};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
    </script>
<div id="piechart"></div>
</div>
</div>
<?php

}
