;(function($){
   $('#loading-infinite').hide();
   $('<div class="loader"></div>').prependTo('body');
   $(window).scroll(function () {
	if ($(window).scrollTop() == ($(document).height() - $(window).height() )) {
		var data_page = $('#loading-infinite').data('page');
		//alert(data_page);
		data_page++;
		loadMoreData(data_page);
	}
  });
function loadMoreData(data_page){
	$.ajax({
		url: frontend_ajax_object.ajax_url,
		type: "get",
		data: {
			action: 'load_more',
			data_page: data_page
		},
		beforeSend: function(){
			$('#loading-infinite').show();
		}
	})
	.done(function(data){
		$('#loading-infinite').hide();
		$('#more-data').append(data);
		$('#loading-infinite').data('page', data_page);
	})
	.fail(function(jqXHR, ajaxOptions, thrownError){
		  $('#more-data').append('<div class="no-more">No More Data</div>');
	});
}	
  $(document).on("click", ".filters a", function(e){
     e.preventDefault();
	 $('.loader').show();
	 var selected = $(this).data('value');
	 $(this).parent().siblings().children().removeClass('active');
        $(this).addClass('active');
	 if(selected == 'wishlisted_price'){
		 $('.slider-show').show();
	 }else{
		 $('.slider-show').hide();
	 }
	 var href = $(this).attr('href');
     //alert(selected);
	 $.ajax({
			type: 'POST',
			url: frontend_ajax_object.ajax_url,
			data: {
				action: 'filter_selected_product',
				selected: selected
			},
			success: function(data) {
				//$( 'div.mode-mini-cart' ).html(data);
				 //alert(data);
				 $('#more-data').html(data);
				 $(".loader").fadeOut("slow");
				 window.history.pushState("object or string", "Title", href);
			}
		});  
	 
     //$(this).parent().remove();
  });
  $(document).on("click", ".save-popular", function(e){
	 var product_id = $(this).closest('.flex-item').data('product_id');												
     //alert(product_id);
	 $.ajax({
			type: 'POST',
			url: frontend_ajax_object.ajax_url,
			data: {
				action: 'popular_product_count',
				product_id: product_id
			},
			async:false,
			success: function(data) {
				//$( 'div.mode-mini-cart' ).html(data);
				//alert(data);
			}
		});  
     //$(this).parent().remove();
  });
  $(document).on("click", ".add-wishlist", function(e){
	var product_id = $(this).closest('.flex-item').data('product_id');	
		 //login_box(500, 300, 'login-box');
	 if($('body').hasClass('logged-in')) {
		 if($(this).closest('article').hasClass('already-vote')	){
			 $('#vote-msg_'+product_id).html('You saved this product');
			 setTimeout(function () {
                $('#vote-msg_'+product_id).hide();
             }, 3000);
		    
		 }else{
			 cast_your_vote(product_id);
		 }
	  }else{
		   $('.login-box .box-content-area').find("input[name=product_id]").val(product_id);
            login_box(500, 300, 'login-box');
	  }
  });
  $(document).on("click", ".login-modal", function(e){
			$('.signup-box').hide();												  
            login_box(500, 300, 'login-box');
  });
  $(document).on("click", ".signup-modal", function(e){
			$('.login-box').hide();													
            login_box(500, 350, 'signup-box');
  });
    $(document).on("click", ".ajax_login", function(e){
	 var nonce        = $(this).data("nonce");
	 var username     = $(this).parent().find("input[name=username_input]");
	 var password     = $(this).parent().find("input[name=password_input]");
	 var product_id = $(this).parent().find("input[name=product_id]");
	 var empty_fields = false;

	 if(!username.val()){
		empty_fields = true;
		username.css("border", "1px solid #F00");
	 } else {
		username.removeAttr("style");
	 }

	 if(!password.val()){
		empty_fields = true;
		password.css("border", "1px solid #F00");
	 } else {
		password.removeAttr("style");
	 }
	//alert(username.val()+password.val()+ product_id.val());
     if(!empty_fields){
		$.ajax({
			url: frontend_ajax_object.ajax_url,
			type: 'POST',
			data: { action: 'user_login', username: username.val(), password: password.val(), pid: product_id.val(), nonce: nonce },
			success:function(response){
			 //alert(response);
			  if(response === "success"){
				$('.login-msg').text("Thank you for saving this product");
				location.reload();
			  }else if(response === "yes"){
				$('.login-msg').text("Thank you for login");
				location.reload(); 
			  }else{
				$('.login-msg').text("Error! - try again later");
				location.reload();
			  }
			}
		});			
	 }
  });
  $(document).on("click", ".ajax_signup", function(e){
			//alert("OK");
		var nonce        = $(this).data("nonce");
		var firstname     = $(this).parent().find(".form-firstname");
		var lastname     = $(this).parent().find(".form-lastname");
		var useremail     = $(this).parent().find(".useremail");
		var password     = $(this).parent().find(".password");
		var empty_fields = false;

		if(!firstname.val()){
			empty_fields = true;
			firstname.css("border", "1px solid #F00");
		} else {
			firstname.removeAttr("style");
		}
		if(!lastname.val()){
			empty_fields = true;
			lastname.css("border", "1px solid #F00");
		} else {
			lastname.removeAttr("style");
		}
		if(!useremail.val()){
			empty_fields = true;
			useremail.css("border", "1px solid #F00");
		} else {
			useremail.removeAttr("style");
		}
		if(!password.val()){
			empty_fields = true;
			password.css("border", "1px solid #F00");
		} else {
			password.removeAttr("style");
		}
	 //alert(firstname.val()+lastname.val()+useremail.val()+password.val()+nonce);
	 if(!empty_fields){
	   jQuery.ajax({
		url: frontend_ajax_object.ajax_url,
		type: 'POST',
		data:{ action:'ajax_register',firstname:firstname.val(),lastname:lastname.val(), useremail:useremail.val(),password:password.val(), nonce:nonce },
		success: function(response){
		 if("success" == response){
		  firstname.removeAttr("style");
		  useremail.removeAttr("style");
		  password.removeAttr("style");
		  lastname.removeAttr("style");
		  location.reload();
		 }else {
		  firstname.css("border", "1px solid #F00");
		  password.css("border", "1px solid #F00");
		  useremail.css("border", "1px solid #F00");
		  lastname.css("border", "1px solid #F00");
		  if(1 == response)
		   $('#vote-msg').text("Email already exist");
		 }
		}
	  });			
	}
  });// function close

  $('.closelog').live('click',function(event){
	$('.modal-overlay').remove();								   
	//Cancel the link behavior
	$('.login-box').hide();
	$('.signup-box').hide();
  });//close click
  function login_box( w, h , boxname){
    var width = w || 600;
	var height = h || 450;
    $('.'+ boxname).css("left", Math.max(0, (($(window).width() - width) / 2) + $(window).scrollLeft()) + "px");
	$('.'+ boxname).css("width", width + "px");
	$('.'+ boxname).css("height", height + "px");
	var docHeight = $(document).height();
   //var ID = $(this).attr('id');
   $("body").append("<div class='modal-overlay'></div>");
   $(".modal-overlay")
      .height(docHeight)
      .css({
         'opacity' : 0.7,
         'position': 'absolute',
         'top': 0,
         'left': 0,
         'background-color': 'black',
         'width': '100%',
         'z-index':9
    });
	$('.'+ boxname).show();
  }//function close
    function cast_your_vote(pid){
	  $.ajax({
		type: "post",
		url: frontend_ajax_object.ajax_url,
		data:{action:"cast_your_vote_now", pid:pid},
		success: function(response) { 
		     //alert(response);
			 if(response === "yes"){
				$('#vote-msg_'+pid).text("Thank you for saving this product");
				setTimeout(function () {
                  $('#vote-msg_'+pid).hide();
                }, 3000);
			 }else{
				$('#vote-msg_'+pid).text("Error! - try again later");
				setTimeout(function () {
                  $('#vote-msg_'+pid).hide();
                }, 3000);
			 }
		}
	 });	
   }//function close

function collision($div1, $div2) {
      var x1 = $div1.offset().left;
      var w1 = 40;
      var r1 = x1 + w1;
      var x2 = $div2.offset().left;
      var w2 = 40;
      var r2 = x2 + w2;
        
      if (r1 < x2 || x1 > r2) return false;
      return true;
      
    }
    
// // slider call

$('#slider').slider({
	range: true,
	min: 0,
	max: 500,
	values: [ 75, 300 ],
	slide: function(event, ui) {
	    price_range_between(ui.values[ 0 ], ui.values[ 1 ]);
		//alert(ui.values[ 0 ]);
		$('.ui-slider-handle:eq(0) .price-range-min').html('$' + ui.values[ 0 ]);
		$('.ui-slider-handle:eq(1) .price-range-max').html('$' + ui.values[ 1 ]);
		$('.price-range-both').html('<i>$' + ui.values[ 0 ] + ' - </i>$' + ui.values[ 1 ] );
		//
    if ( ui.values[0] == ui.values[1] ) {
      $('.price-range-both i').css('display', 'none');
    } else {
      $('.price-range-both i').css('display', 'inline');
    }
        //
		if (collision($('.price-range-min'), $('.price-range-max')) == true) {
			$('.price-range-min, .price-range-max').css('opacity', '0');	
			$('.price-range-both').css('display', 'block');		
		} else {
			$('.price-range-min, .price-range-max').css('opacity', '1');	
			$('.price-range-both').css('display', 'none');		
		}
	}
});

$('.ui-slider-range').append('<span class="price-range-both value"><i>$' + $('#slider').slider('values', 0 ) + ' - </i>' + $('#slider').slider('values', 1 ) + '</span>');

$('.ui-slider-handle:eq(0)').append('<span class="price-range-min value">$' + $('#slider').slider('values', 0 ) + '</span>');

$('.ui-slider-handle:eq(1)').append('<span class="price-range-max value">$' + $('#slider').slider('values', 1 ) + '</span>');
	
  function price_range_between(low, high){
	  $('.loader').show();
	  $.ajax({
		type: "post",
		url: frontend_ajax_object.ajax_url,
		data:{action:"product_price_range_between", low:low, high:high},
		success: function(response) { 
		     //alert(response);
			 $('#more-data').html(response);
			 $(".loader").fadeOut("slow");
		}
	 });	
  }//function close
 $(document).on("click", ".menu-top-navigation-container .login a", function(e){
     e.preventDefault();
	 var href = $(this).attr('href');
	 if(href == '#login'){
	   login_box(500, 300, 'login-box');
	 }else if(href == '#signin'){
	   login_box(500, 350, 'signup-box'); 
	 }
 });
})(jQuery);

jQuery(document).ready(function($){
								
});