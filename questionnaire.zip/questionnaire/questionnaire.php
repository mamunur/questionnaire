<?php 
/* 
Plugin Name:Questionnaire
Description: <strong>Auto Quotes and Orders</strong>  This is a very simple leight-weight plugin to get a quotation for auto trasportation and make an order.
Author: Md Mamunur Rahman 
Version: 1.0.0 
Author URI:http://mashfiq.tk/mamun/
*/ 
//********************************************
//	Constant Paths
//***********************************************************
register_activation_hook(__FILE__,'set_questionnaire_options');
if( !defined("FEED_HOME") ){
	define("FEED_HOME", plugin_dir_path( __FILE__ ));
}

if( !defined('FEED_DIR') ){
	define( 'FEED_DIR', plugins_url() . '/questionnaire/' );
}

if( !defined("JS_DIR") ){
	define("JS_DIR", FEED_DIR . "js/");
}

if( !defined("CSS_DIR") ){
	define("CSS_DIR", FEED_DIR . "css/");
} 
//For admin style and script enqueue
function questionnaire_admin_scripts($hook_suffix){
	wp_enqueue_script( 'jquery' );
wp_register_style('admin_styles', CSS_DIR. 'admin_style.css', array(), WC_VERSION );
wp_enqueue_style('admin_styles' );
wp_enqueue_script( 'jsapi', 'https://www.gstatic.com/charts/loader.js', 1 );

  wp_enqueue_script( 'ethershop_admin', plugins_url( '/js/admin.js', __FILE__ ), array('jquery'), '1.0', true );
    wp_localize_script( 'ethershop_admin', 'ajax_object', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' )
    )); 
        
}
//For user style and script enqueue
add_action( 'admin_enqueue_scripts', 'questionnaire_admin_scripts' );
function questionnaire_scripts () { 
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_style('font-awesome', CSS_DIR . 'font-awesome.css' );
wp_enqueue_style('listing_css', CSS_DIR . 'listing_style.css' );
wp_enqueue_script('quotation', JS_DIR . 'custom.js', array('jquery'), false, true); 
    // You need styling for the datepicker. For simplicity I've linked to Google's hosted jQuery UI CSS.
    wp_register_style('jquery-ui', 'https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css');
    wp_enqueue_style('jquery-ui');

    if (!wp_script_is('jquery-ui')) {
        // you don't have to use googleapi's, but I think it helps. It saves the user's browser from loading the same script again if it has already been loade>
        wp_enqueue_script('jquery-ui', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js');
    }  
  wp_localize_script('quotation', 'frontend_ajax_object',
    array( 
        'ajax_url' => admin_url( 'admin-ajax.php' ))
  );
} 
add_action( 'wp_enqueue_scripts', 'questionnaire_scripts' ); 
function set_questionnaire_options(){
    global $wpdb;

    $questionnaire = $wpdb->prefix . 'questionnaire'; // Students

    $answers = $wpdb->prefix . 'answers'; // Courses

    $charset_collate = '';
    if ( version_compare(mysql_get_server_info(), '4.1.0', '>=') ) {
        if ( ! empty($wpdb->charset) ) {
            $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
        }	
        if ( ! empty($wpdb->collate) ) {
            $charset_collate .= " COLLATE $wpdb->collate";
        }
        $charset_collate .= " ENGINE = InnoDB";
    }
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $table_name = $questionnaire;

    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE $questionnaire (
  				`id` int(10) NOT NULL AUTO_INCREMENT,
				`submit_by` int(11) NOT NULL,
				`question` text NOT NULL,
  				`created` datetime NOT NULL,
  				`updated`  datetime NOT NULL,
  				PRIMARY KEY (`id`)
		) $charset_collate;";

        dbDelta($sql);
	}//if

	$table_name = $answers;

    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
	    $sql = "CREATE TABLE $answers (
  				`id` int(11) NOT NULL AUTO_INCREMENT,
  				`qid` int(11) NOT NULL,
  				`answered_by` int(11) NOT NULL,
  				`answer` int(11) NOT NULL,
				`ip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  				`cdate` datetime NOT NULL,
  				PRIMARY KEY (`id`)
					)$charset_collate;";
	  dbDelta($sql);
	}//if

}// function close
  require_once 'functions/functions.php';
  require_once 'include/questionnaire-menu.php';
  require_once 'shortcodes/shortcodes.php';
  //require_once 'widgets/qfunctions.php';
  require_once 'widgets/question-answer.php';
  
?>