<?php 
function amazon_product_listing_shortcode_function($attr) {
$shortcode_args = shortcode_atts(array('filter' => ''),$attr);
$subpage = get_query_var('sub_page');
 $output ="";
 $loop ="";
 global $wpdb;
//echo "<pre>".print_r($zipcode, 1)."</pre>";
//echo $pagelink;
//amazon_api_connect();
//$response = getItemByAsin("com", "B01IDE9M76");
//$response = getItemByKeyword("com", "barn wood", "Kitchen");
//echo "<pre>".print_r($response, 1)."</pre>";

$args = array(
'taxonomy' => 'product_cat',
'orderby' => 'date',
'order'      => 'ASC',
'show_count' => 0,
'pad_counts' => 0,
'hierarchical' => 1,
'title_li' => '',
'hide_empty' => 0
); 
$catagories = get_categories( $args );
//$terms = get_terms('product_cat');
ob_start();
//echo $search_result->found_posts;
//echo "<pre>".print_r($ahortcode_args, 1)."</pre>";
//$products_args = array('orderby' => 'post_date');
?>
<div class="product-container">

<?php
if(($shortcode_args['filter'] == "new") || ($shortcode_args['filter'] == "")){
 $defaults_args = array('posts_per_page' => 5,
						'paged'			 => 1,
						'orderby' => 'post_date',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
$new = " active "; $popular = $random = $wishlisted_price = '';
}elseif($shortcode_args['filter'] == "popular"){
 $defaults_args = array('posts_per_page' => 5,
						'paged'			 => 1,
						'meta_key' => '_popular_product', 
						'orderby'  => 'meta_value_num',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
$popular = " active "; $new = $random = $wishlisted_price = '';
}elseif($shortcode_args['filter'] == "random"){
 $defaults_args = array('posts_per_page' => 5,
						'paged'			 => 1,
						'orderby' 		=> 'rand',
						'post_type' 	=> 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
$random = " active "; $new = $popular = $wishlisted_price = '';
}elseif($shortcode_args['filter'] == "under20"){
 $defaults_args = array('posts_per_page' => 5,
						'paged'			 => 1,
						'meta_query' => array(
						   array(
							'key' => '_price',
							'value' => 20,
							'compare' => '<=',
							'type' => 'NUMERIC'
							),
						   ),
						'orderby' 		=> 'meta_value_num',
						'post_type' 	=> 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'ASC',
						);
?>
<style>						
.filter-show{
   display:none;
}
</style>
<?php
}elseif($shortcode_args['filter'] == "wishlisted_price"){
 $defaults_args = array('posts_per_page' => 5,
						'paged'			 => 1,
						'meta_key' => '_voting_count', 
						'orderby'  => 'meta_value_num',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'ASC',
						);
$wishlisted_price = " active "; $new = $popular = $random = '';
?>
<style>						
.slider-show{
   display:block;
}
</style>
<?php
}
?>
<div class="filters filter-show">
 <ul class="nav">
   <li><a class="<?php echo $new; ?> auto-localize" data-value="new" href="/new/">Newest</a></li>
   <li><a class="<?php echo $popular; ?> auto-localize" data-value="popular" href="/popular/">Popular <?php echo $subpage; ?></a></li>
   <li><a class="<?php echo $wishlisted_price; ?> auto-localize" data-value="wishlisted_price" href="/wishlisted-price/">Price Range</a></li>
   <li><a class="<?php echo $random; ?> auto-localize" data-value="random" href="/random/">Random</a></li>
 </ul>
</div>
<div class="price-ranger">
  <div class="price-slider">
      <div id="slider" class="slider-show"></div>
  </div>
</div>

<div class="grid-view">
<div class="flex-container home" id="more-data">
<?php
foreach ($catagories as $category) :
 $term_id 	= $category->term_id; // Term ID
 $tax_args = array(
			      'tax_query' 	 => array( 
				    array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id, 
				    ),
			      ),
		         );
$products_args =	wp_parse_args( $tax_args, $defaults_args );
$search_result = new WP_Query( $products_args );
 include 'data.php';
endforeach;
?>
</div><!--flex-container home-->
<div id="loading-infinite" data-page="1" ><img src="<?php echo FEED_DIR.'images/loading.gif'; ?>"  /></div>
</div><!--grid-->
</div>
<?php
return ob_get_clean();
}

add_shortcode( 'amazon_product_listing', 'amazon_product_listing_shortcode_function');

function ajax_load_more() {
    // Set item key as the hash found in input.qty's name
$data_page = $_REQUEST['data_page'];
$args = array(
'taxonomy' => 'product_cat',
'orderby' => 'date',
'order'      => 'ASC',
'show_count' => 0,
'pad_counts' => 0,
'hierarchical' => 1,
'title_li' => '',
'hide_empty' => 0
); 
$catagories = get_categories( $args );
ob_start();
foreach ($catagories as $category) :
 $term_id 	= $category->term_id; // Term ID
 $products_args = array(
		'posts_per_page' => 15,
		'paged'			 => $data_page,
		'tax_query' 	 => array( 
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id, 
				),
			),
		'post_type' => 'product',
		'post_status'  => 'publish',
  		'orderby' 	   => 'post_date',
  		'order' 	   => 'DESC',
        );
 $search_result = new WP_Query( $products_args );
 include 'data.php';
endforeach;
    // Refresh the page
    echo ob_get_clean();
    die();
}

add_action('wp_ajax_load_more', 'ajax_load_more');
add_action('wp_ajax_nopriv_load_more', 'ajax_load_more');

function ajax_filter_selected_product() {
$args = array(
'taxonomy' => 'product_cat',
'orderby' => 'date',
'order'      => 'ASC',
'show_count' => 0,
'pad_counts' => 0,
'hierarchical' => 1,
'title_li' => '',
'hide_empty' => 0
); 
$catagories = get_categories( $args );
$selected = $_POST['selected'];
if(($selected == "new") || ($selected == "")){
  $defaults_args = array('posts_per_page' => 15,
						'paged'			 => 1,
						'orderby' => 'post_date',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
}elseif($selected == "popular"){
 $defaults_args = array('posts_per_page' => 15,
						'paged'			 => 1,
						'meta_key' => '_popular_product', 
						'orderby'  => 'meta_value_num',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
}elseif($selected == "random"){
 $defaults_args = array('posts_per_page' => 15,
						'paged'			 => 1,
						'orderby' 		=> 'rand',
						'post_type' 	=> 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
						);
}elseif($selected == "wishlisted_price"){
 $defaults_args = array('posts_per_page' => 15,
						'paged'			 => 1,
						'meta_key' => '_voting_count', 
						'orderby'  => 'meta_value_num',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'ASC',
						);
}
ob_start();
foreach ($catagories as $category) :
 $term_id 	= $category->term_id; // Term ID
 $tax_args = array(
			      'tax_query' 	 => array( 
				    array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id, 
				    ),
			      ),
		         );
 $products_args = wp_parse_args($tax_args, $defaults_args);
 $search_result = new WP_Query( $products_args );
 include 'data.php';
endforeach;
    echo ob_get_clean();
    die();
}

add_action('wp_ajax_filter_selected_product', 'ajax_filter_selected_product');
add_action('wp_ajax_nopriv_filter_selected_product', 'ajax_filter_selected_product');

function ajax_popular_product_count() {
    // Set item key as the hash found in input.qty's name
$product_id = $_POST['product_id'];
$popular = get_post_meta($product_id, '_popular_product', true);
$popular = $popular +1;
update_post_meta($product_id, '_popular_product', $popular);
//echo $popular;
    die();
}

add_action('wp_ajax_popular_product_count', 'ajax_popular_product_count');
add_action('wp_ajax_nopriv_popular_product_count', 'ajax_popular_product_count');

function cast_your_vote_now(){
global $wpdb;
$voting = array();
	if(!empty($_POST)) {
	  $pid = $_POST['pid'];
	}//outer if close
	$voting_count = get_post_meta($pid, "_voting_count",true);
	if ( is_user_logged_in ) {
	 global $current_user;
	 $uid = $current_user->ID;
	 $voting_stat = get_usermeta($current_user->ID, '_voting', true);
	 $voting = json_decode($voting_stat, true);
	 if(!empty($voting)){
	  if (!array_key_exists($pid, $voting)) {
       $voting[$pid] = 1;
	   $save_voting = json_encode($voting);
	   update_user_meta($current_user->ID, '_voting', $save_voting);
	   $voting_count += 1;
	   update_post_meta((int)$pid, "_voting_count", $voting_count);
	   echo "yes";
			 //echo "<pre>".print_r($voting, 1)."<pre>";
	  }
	 }else{
	   $voting[$pid] = 1;
	   $save_voting = json_encode($voting);
	   update_user_meta($current_user->ID, '_voting', $save_voting);
	   $voting_count += 1;
	   update_post_meta((int)$pid, "_voting_count", $voting_count);
	   echo "yes";
	 }
    }
    //echo $emailid;
    die();
//echo $fname." ".$emailid." ".$schedule_str." ".$webinar_id." ".$campaignid." ".$webinar_type." ".$c_code." ".$phone;
}//function close
  add_action("wp_ajax_cast_your_vote_now", "cast_your_vote_now");
  add_action("wp_ajax_nopriv_cast_your_vote_now", "cast_your_vote_now");
  
function user_login(){
    $username = $_POST['username'];
    $password = $_POST['password'];
	$pid = $_POST['pid'];
    $nonce    = $_POST['nonce']; 
    $remember = (isset($_POST['remember_me']) && !empty($_POST['remember_me']) ? $_POST['remember_me'] : "");

  if ( wp_verify_nonce( $nonce, 'ajax_login_nonce' ) && !empty($username) && !empty($password) ) {
        $creds = array();
        $creds['user_login']    = sanitize_text_field($username);
        $creds['user_password'] = sanitize_text_field($password);
        $creds['remember_me']   = sanitize_text_field(($remember == "yes" ? true : false));

        $user = wp_signon( $creds, false );
        if (!is_wp_error($user) && (isset($pid) && !empty($pid))) {
		  	$voting_count = get_post_meta($pid, "_voting_count",true);
	        $voting = get_usermeta($user->ID, '_voting', true);
            if(!empty($voting)){
			 if (!array_key_exists($pid, $voting)) {
			   $voting[$pid] = 1;
			   update_user_meta($user->ID, '_voting', $voting);
			   $voting_count += 1;
			   update_post_meta((int)$pid, "_voting_count", $voting_count);
			   echo "success";
			 }
		    }else{
			   $voting[$pid] = 1;
			   update_user_meta($user->ID, '_voting', $voting);
			   $voting_count += 1;
			   update_post_meta((int)$pid, "_voting_count", $voting_count);
			   echo "success";
		    }
        }elseif(!is_wp_error($user)){
		  echo "yes";
		}
    }
    die;
}//function close
add_action("wp_ajax_user_login", "user_login");
add_action("wp_ajax_nopriv_user_login", "user_login");
function ajax_register(){
    $firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$uemail = $_POST['useremail'];
    $password = $_POST['password'];
    $nonce    = $_POST['nonce'];
$user = get_user_by( 'email', $uemail );
if( isset($user) && !empty($user)):
     echo "1";
else:
    if ( wp_verify_nonce( $nonce, 'ajax_signup_nonce' ) && !empty($firstname) && !empty($uemail) && !empty($password) && !empty($lastname)) {
	
    $loginid = mb_substr($uemail, 0, strpos($uemail, '@'),'UTF-8');
    $user_id = wp_create_user( $loginid, $password, $uemail );
	wp_set_auth_cookie($user_id);

	update_user_meta( $user_id, 'firstname', $firstname );
	update_user_meta( $user_id, 'lastname', $lastname );
	$to_Email       = $uemail;
    $subject        = __('Message from new registration of ilovebarnwood.com ', 'educare');
    $user_Message     = 'Hi '.$username.'<br/> Your registration been completed.';
	$user_Message     .= 'You can login by '.$loginid .' at <a href="http://www.ilovebarnwood.com/wp-admin/"> $firstname </a>';
	$user_Message     .='<br/><br/><br/>Regards <br/>Team Expliciet.';
	$headers = array();
    $headers[] = 'From: ' . get_option( 'admin_email' );
	$sentMail = @wp_mail($to_Email, $subject, $user_Message , $headers);
	        echo 'success';

    }
endif;
    die;
}

add_action("wp_ajax_ajax_register", "ajax_register");
add_action("wp_ajax_nopriv_ajax_register", "ajax_register");

function product_price_range_between(){
global $wpdb;
$args = array(
'taxonomy' => 'product_cat',
'orderby' => 'date',
'order'      => 'ASC',
'show_count' => 0,
'pad_counts' => 0,
'hierarchical' => 1,
'title_li' => '',
'hide_empty' => 0
); 
$catagories = get_categories( $args );
	if(!empty($_POST)) {
	  $low = $_POST['low'];
	  $high = $_POST['high'];
	}
 $defaults_args = array('posts_per_page' => 15,
						'paged'			 => 1,
						'meta_query' => array(
						   array(
							'key' => '_price',
							'value' => array($low, $high),
							'compare' => 'BETWEEN',
							'type' => 'NUMERIC'
							),
						   ),
						'orderby'  => 'meta_value_num',
						'post_type' => 'product',
						'post_status'  => 'publish',
  						'order' 	   => 'DESC',
				   );

foreach ($catagories as $category) :
 $term_id 	= $category->term_id; // Term ID
 $tax_args = array(
			      'tax_query' 	 => array( 
				    array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id, 
				    ),
			      ),
		         );
 $products_args = wp_parse_args($tax_args, $defaults_args);
 $search_result = new WP_Query( $products_args );
 include 'data.php';
endforeach;
    echo ob_get_clean();	
    //echo $low." ".$high;
    die();
//echo $fname." ".$emailid." ".$schedule_str." ".$webinar_id." ".$campaignid." ".$webinar_type." ".$c_code." ".$phone;
}//function close
  add_action("wp_ajax_product_price_range_between", "product_price_range_between");
  add_action("wp_ajax_nopriv_product_price_range_between", "product_price_range_between");

function amazon_product_listing_bycategory_shortcode_function($attr) {
$shortcode_args = shortcode_atts(array('category' => ''),$attr);
$term_slug = $shortcode_args['category'];

if($term_slug == '')
  return;
$term = get_term_by('slug', $term_slug, 'product_cat'); 
$term_id = $term->term_id;
//$terms = get_terms('product_cat');
ob_start();
//echo $search_result->found_posts;
//echo "<pre>".print_r($ahortcode_args, 1)."</pre>";
//$products_args = array('orderby' => 'post_date');
?>
<div class="product-container">
<h1><?php echo $term->name; ?></h1>
<div class="grid-view">
<div class="flex-container home" id="more-data">
<?php
 $products_args = array(
                  'posts_per_page' => 30,
				  'paged'			 => 1,
				  'post_status'  => 'publish',
                  'post_type' => 'product',
            	  'orderby' => 'post_date',
				  'order' 	   => 'DESC',
			      'tax_query' 	 => array( 
				    array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $term_id, 
				    ),
			      ),
		         );
 $search_result = new WP_Query( $products_args );
 include 'data.php';
?>
</div><!--flex-container home-->
<div id="loading-infinite" data-page="1" ><img src="<?php echo FEED_DIR.'images/loading.gif'; ?>"  /></div>
</div><!--grid-->
</div>
<?php
return ob_get_clean();
}

add_shortcode( 'amazon_product_listing_bycategory', 'amazon_product_listing_bycategory_shortcode_function');
