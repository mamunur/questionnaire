<?php
function question_answer(){
echo 'I am here'

}//function close